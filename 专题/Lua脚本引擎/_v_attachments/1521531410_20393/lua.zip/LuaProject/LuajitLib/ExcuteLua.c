#include "ExcuteLua.h"

#include "lualib.h"
#include "lauxlib.h"

void ExcuteLuaString( const char* lpBuffer, unsigned long ulBufferSize )
{
    int nStatus = 0;
    lua_State* L = luaL_newstate();
    luaL_openlibs(L);
    nStatus = luaL_loadbufferx( L, lpBuffer, ulBufferSize, NULL, NULL );
    nStatus = lua_pcall(L, 0, 0, 0);
    lua_close(L);
}
