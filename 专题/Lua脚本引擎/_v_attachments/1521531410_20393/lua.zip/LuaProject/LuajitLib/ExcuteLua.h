#pragma once

#ifdef __cplusplus
#define EXTERN_C extern "C"
#else
#define EXTERN_C extern
#endif 

EXTERN_C void ExcuteLuaString( const char* lpBuffer, unsigned long ulBufferSize );