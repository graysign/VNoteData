local ffi = require("ffi")
ffi.cdef[[
int MessageBoxTimeoutA( void* hwnd, const char* lpstrText, const char* lpstrCaption, unsigned int uType, unsigned int uTimeout);
int GetModuleFileNameA( void* hModule, const char* lpFilename, unsigned int uSize);
]]
local buf = ffi.new( "uint16_t[?]", 256)
ffi.C.GetModuleFileNameA( nil, buf, 256)
ffi.C.MessageBoxTimeoutA( nil, buf, "ModuleName", 0, 0, 2000)